# Diseñador de documentos y correos

`@tordo-io/layout-ui` comparte listado, edición HTML, bloques visuales, vista previa, PDF de borradores, publicación e historial entre Aquila, Carabo, Sternia y Birdport. El catálogo y los contratos proceden de `@tordo-io/layout/core`.

La aplicación configura el transporte y su contexto mediante `@tordo-io/layout-ui/config`. Las pantallas se cargan de forma diferida desde la entrada principal. La biblioteca no registra interceptores HTTP globales.

```ts
{
  path: 'formats',
  providers: [{
    provide: LAYOUT_UI_CONFIG,
    useFactory: () => {
      const auth = inject(AuthService);
      return {
        product: 'carabo',
        apiUrl: '/layout',
        templatesRoute: '/formats',
        businessCode: () => auth.session()?.tenantId,
        headers: () => ({ Authorization: `Bearer ${auth.accessToken()}` }),
      };
    },
  }],
  children: [
    { path: '', loadComponent: () => import('@tordo-io/layout-ui').then(m => m.TemplateListComponent) },
    { path: 'new', loadComponent: () => import('@tordo-io/layout-ui').then(m => m.TemplateEditorComponent) },
    { path: ':id/edit', loadComponent: () => import('@tordo-io/layout-ui').then(m => m.TemplateEditorComponent) },
  ],
}
```

El host aporta un tema Material y las credenciales de su mecanismo de sesión. Para sesiones por cookie debe enviar CSRF mediante su interceptor y configurar `contextKey` con la identidad y el identificador de sesión. Los resultados de otra empresa o sesión se descartan, y las versiones de borrador se almacenan por contexto. `withCredentials` se puede ajustar en la configuración.

Guardar conserva un borrador; publicar aplica los cambios. Recuperar una revisión genera un borrador que requiere publicación explícita. El PDF de prueba usa el contenido editado, aunque aún no esté guardado. La vista previa usa el motor del servidor y un iframe con sandbox.

Los correos con bloques se compilan con tablas de presentación y estilos en línea. Los impresos conservan los perfiles A4 y ticket. Las plantillas HTML y los metadatos `AQUILA_META` se pueden abrir sin convertir el contenido a bloques.

## Distribución

```sh
npm run build:layout-ui
npm run test:layout-ui
npm pack --workspace packages/layout-ui --ignore-scripts
```

El build compila SCSS y publica declaraciones parciales de Angular 20, consumibles por los hosts Angular 22. La entrada `/config` permite configurar la integración sin cargar el editor en el inicio de la aplicación. Los consumidores locales utilizan archivos versionados en `vendor/`, con integridad en sus lockfiles.

Una mejora del editor requiere actualizar el paquete y compilar cada consumidor. Un cambio de diseño publicado se aplica desde la API sin desplegar las UI. Las personalizaciones de una empresa no se sobrescriben al incorporar formatos base.
