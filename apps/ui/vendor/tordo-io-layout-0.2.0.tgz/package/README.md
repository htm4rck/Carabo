# Layout

`@tordo-io/layout/core` contiene el catálogo documental, contratos, selección de plantillas y reglas de borrador/publicación. La API ejecutable está en `tordo/apps/layout`; el diseñador Angular se distribuye como `@tordo-io/layout-ui` desde `tordo-ui`.

| Aplicación | Catálogo |
|---|---|
| Aquila | Todos los documentos y formatos base |
| Carabo | Comprobantes y guías electrónicas |
| Sternia | Compras, documentos internos e inventario |
| Birdport | Correos de pedidos y de cuentas de clientes |

`layoutDocumentTypes(product)` expone nombres, canales, formatos, variables obligatorias y datos de ejemplo. `defaultLayoutDesign(code)` entrega un diseño inicial completo. Las reglas de publicación comprueban el formato, el asunto del correo y las variables obligatorias. Los datos y cálculos de negocio pertenecen al productor del documento.

## Borradores y publicación

`LayoutDesignUseCases` usa `LayoutDesignStore` y `LayoutDesignUnitOfWork`. Crear o guardar modifica el borrador. Publicar copia el contenido al formato utilizado por PDF/correo y registra una revisión. Guardar y publicar requieren la versión leída; una versión desactualizada produce `TEMPLATE_VERSION_CONFLICT`. Código, tipo y formato son inmutables durante la edición.

`editorDocument` conserva JSON con `schemaVersion: 1`, modo `html` o `blocks` y el contenido editable. El HTML publicado se mantiene separado del estado del editor. El adaptador de renderizado interpreta los bloques importados de Aquila y genera sus códigos en el servidor.

La selección compartida `resolveLayoutTemplate` busca código explícito, predeterminado y primer formato disponible. Un código de otro documento o formato se rechaza con `TEMPLATE_SCOPE_MISMATCH`. La provisión de formatos base conserva los códigos y predeterminados propios de la empresa.

## Verificación

```sh
npm run build --workspace packages/layout
node --require ./scripts/register-test-sources.cjs --test tests/layout-designs.cjs tests/homologation-domains.cjs
```

Los controles de identidad, empresa y permisos se ejecutan en la API. El filtrado del catálogo en una UI no concede autorización.
