# @tordo-io/commons

Base utilities and services shared across all Tordo backend microservices.

## Features

- `DatabaseConnectionManager` — multi-tenant connection management
- `bootstrapNestApp` — standardized NestJS app bootstrap with winston, swagger, metrics
- `HealthController` — `/health` endpoint
- `ApiResponse` — unified response wrapper
- `AuditableEntity` — base entity with createdAt/updatedBy/deletedAt
- `AllExceptionsFilter` — global error handling
- `RabbitMQ` producer/consumer
- `MailPublisherService` — publish emails to mailer queue
- `BusinessHeaderUtil` — extract business-code from request headers
- Metrics middleware (prom-client)

## Usage

```typescript
import { DatabaseConnectionManager, bootstrapNestApp, HealthController, ApiResponse } from '@tordo-io/commons';
```
